<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\User;
class ProductController extends Controller
{
    //

    function index(){
        $data= Product::all();
        return view('products',['products'=> $data]);
    }

    function detail($id){
        $data = Product::find($id);
        return view('detail',['products' => $data]);
    }

    function search(Request $req){
       
        //return $req->input();
         $data = Product:: where('name', 'like','%'.$req->input('forsearch').'%')->get();
         return view('search',['products'=> $data]);
    }

    function addToCart(Request $req){
        // $data = $req->session()->all();
        // return view('login',['products' => $data]);



     if($req->session->has( Auth::user()->name))
     if($req->session()->has('URL'))
      {
          return "Hello";
      }
      else{
        return redirect("/login");
      }
      
    }
}
