{{-- @extends('master')
@section('content')
    
@endsection --}}


{{print_r($products)}}