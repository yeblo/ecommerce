


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class ="col text-center">
                <div class="text-left">
                <a href="/home"> Go Back </a>
                </div>
                <h1 class="py-4 for_logo2"><?php echo e($products['name']); ?></h1>
                <h3>$ <?php echo e($products['price']); ?></h3>
                <div class="text-left py-4">
                <p> <?php echo e($products['description']); ?></p>
                </div>
                <form action="/add_to_cart" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value = <?php echo e($products['id']); ?>>
                <button class ="btn btn-primary">Add to Cart</button>
                <button class ="btn btn-success">Buy Now</button>
                </form>
               
            </div>
            <div class ="col">
                <img class="detail-img" src="<?php echo e(asset($products['gallery'])); ?>" alt="">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/detail.blade.php ENDPATH**/ ?>