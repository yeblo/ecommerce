

<?php $__env->startSection('content'); ?>
<div class= "container text-center">
    <h3 class=""> Search Results</h3>

    <hr>
</div>
<div class="container">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
        <div class = "col-lg-4 col-md-6 col-sm-12 p-3">
            <div class="card " style="width: 18rem;">
                <img class="card-img-top" style= "height: 200; width: 290;" src="<?php echo e(asset($prod->gallery)); ?>" alt="Card image cap">
                <div class="card-body">    
                    <h3 class="text-center for_logo2 text-dark"><a href="detail/<?php echo e($prod['id']); ?>"><?php echo e($prod->name); ?></a></h3>
                        <hr>
                    <p class="card-text text-left">$<?php echo e($prod->price); ?> <span title="quick look" style="float: right"> <a href="detail/<?php echo e($prod['id']); ?>" style="color: grey;"><i class="fas fa-eye"></i></a></span></p>
                    
                </div>
              </div>
            </div>
        
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/search.blade.php ENDPATH**/ ?>