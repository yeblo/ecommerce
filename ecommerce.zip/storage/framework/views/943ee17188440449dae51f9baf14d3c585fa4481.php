


<?php echo e(print_r($products)); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/login.blade.php ENDPATH**/ ?>